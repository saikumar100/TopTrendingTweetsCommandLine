package com.sai.proposal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProposalApplicationTests {

	@Test
	void contextLoads() {
	}

}
